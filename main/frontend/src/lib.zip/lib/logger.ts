type LogLevel = 'debug' | 'info' | 'warn' | 'error';

interface LogEntry {
  timestamp: string;
  level: LogLevel;
  message: string;
  data?: any;
  context?: string;
}

class Logger {
  private static instance: Logger;
  private isDev: boolean;

  private constructor() {
    this.isDev = process.env.NODE_ENV === 'development';
  }

  public static getInstance(): Logger {
    if (!Logger.instance) {
      Logger.instance = new Logger();
    }
    return Logger.instance;
  }

  private formatEntry(level: LogLevel, message: string, data?: any, context?: string): LogEntry {
    return {
      timestamp: new Date().toISOString(),
      level,
      message,
      data,
      context,
    };
  }

  private print(entry: LogEntry) {
    const { timestamp, level, message, data, context } = entry;
    const contextStr = context ? `[${context}]` : '';
    const formattedMessage = `[${timestamp}] ${level.toUpperCase()} ${contextStr} ${message}`;

    const style = {
      debug: 'color: #9ca3af', // gray-400
      info: 'color: #3b82f6',  // blue-500
      warn: 'color: #f59e0b',  // amber-500
      error: 'color: #ef4444', // red-500
    };

    if (this.isDev) {
      console.groupCollapsed(`%c${formattedMessage}`, style[level]);
      if (data) {
        console.log('Data:', data);
      }
      console.trace('Stack Trace');
      console.groupEnd();
    } else {
      // In production, we might want to just log the object or send it to a service
      // For now, we keep console logs but less verbose if needed, or structured
      if (level === 'error' || level === 'warn') {
        console[level](formattedMessage, data || '');
      }
    }
  }

  public debug(message: string, data?: any, context?: string) {
    this.print(this.formatEntry('debug', message, data, context));
  }

  public info(message: string, data?: any, context?: string) {
    this.print(this.formatEntry('info', message, data, context));
  }

  public warn(message: string, data?: any, context?: string) {
    this.print(this.formatEntry('warn', message, data, context));
  }

  public error(message: string, error?: any, context?: string) {
    this.print(this.formatEntry('error', message, error, context));
  }
}

export const logger = Logger.getInstance();
