import axios, { AxiosInstance, AxiosResponse, AxiosError } from 'axios';
import { ApiResponse } from '@/types/api';
import { logger } from './logger';
import { useAuthStore } from '@/store/use-auth-store';

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:8000/api/v1';

const request: AxiosInstance = axios.create({
  baseURL: API_BASE_URL,
  timeout: 30000,
  headers: {
    'Content-Type': 'application/json',
  },
});

request.interceptors.request.use(
  (config) => {
    // Log Request
    logger.debug(`Request: ${config.method?.toUpperCase()} ${config.url}`, config.data, 'API');

    if (typeof window !== 'undefined') {
      const token = localStorage.getItem('access_token');
      if (token) {
        config.headers.Authorization = `Bearer ${token}`;
      }
    }
    return config;
  },
  (error) => {
    logger.error('Request Error', error, 'API');
    return Promise.reject(error);
  }
);

request.interceptors.response.use(
  (response: AxiosResponse<ApiResponse>) => {
    // Log Response
    logger.debug(`Response: ${response.config.method?.toUpperCase()} ${response.config.url}`, response.data, 'API');

    // Unpack standard response structure: { code, message, data }
    const { code, message, data } = response.data;
    
    // If the backend returns a wrapper with code
    if (code !== undefined) {
      if (code === 200) {
        return data; // Return the inner data
      } else {
        const errMsg = message || `Error ${code}`;
        logger.warn(`API Business Error: ${errMsg}`, response.data, 'API');
        return Promise.reject(new Error(errMsg));
      }
    }
    
    // Fallback for endpoints that might not use the wrapper (if any)
    return response.data;
  },
  (error: AxiosError) => {
    if (error.response) {
      const { status, data } = error.response;
      
      logger.error(`API Error Response: ${status}`, data, 'API');

      if (status === 401) {
        if (typeof window !== 'undefined') {
          // Clear auth state in store
          useAuthStore.getState().logout();
          // Dispatch unauthorized event to trigger UI (e.g. open login modal)
          window.dispatchEvent(new Event('auth:unauthorized'));
        }
      }
      
      // Try to extract backend error message
      let backendMessage = (data as any)?.message || (data as any)?.detail || error.message;
      
      // Handle array of errors (e.g. FastAPI validation errors)
      if (Array.isArray(backendMessage)) {
        backendMessage = backendMessage.map((e: any) => e.msg || JSON.stringify(e)).join(', ');
      } else if (typeof backendMessage === 'object' && backendMessage !== null) {
        backendMessage = JSON.stringify(backendMessage);
      }
      
      return Promise.reject(new Error(backendMessage));
    }
    
    logger.error('Network Error', error.message, 'API');
    return Promise.reject(error);
  }
);

export default request;
